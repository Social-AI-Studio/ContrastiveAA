import argparse
import sys
sys.path.append("/home/thao/home/contrastive_aa/src/")

import torch
import torch.cuda
from torch.utils.data import DataLoader
from torch.nn.parallel import DataParallel

from dataloader import *
from content_encoder import *
from style_encoder import *
from dual_encoder import *
from MI_loss import *

def main(
    batch_size: int,
    num_epochs: int,
    log_step: int,
    num_iters: int,
    save_dir: str,
    ):
    torch.backends.cudnn.benchmark = True
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    # Preare data
    data_files = {
        "train": "/home/thao/home/contrastive_aa/data/AA_data/AA_cls_train.json", 
        "test": "/home/thao/home/contrastive_aa/data/AA_data/AA_cls_test.json"}
    
    # train_data, test_data = get_dataset(data_files=data_files)
    train_data, test_data = get_samples(data_files=data_files,len_train_sample=10000, len_test_sample=10000)
    style_checkpoint = "/home/thao/home/contrastive_aa/AA_test/AA_test_res"
    content_checkpoint = "bert-base-uncased"

    # Build model
    style_encoder = StyleEncoder(checkpoint=style_checkpoint, 
                                 train_data=train_data, 
                                 test_data=test_data)
    
    content_encoder = ContentEncoder(checkpoint=content_checkpoint,
                                     train_data=train_data,
                                     test_data=test_data)
    
    dual_encoder = DualEncoder(content_encoder=content_encoder,
                               style_encoder=style_encoder,
                               num_epochs=num_epochs,
                               batch_size=batch_size,
                               num_iters=num_iters,
                               log_step=log_step)

    # Train Step
    print("-------------------- Training --------------------")

    # device_ids = [1, 0]
    # memory_fractions = [0.5, 0.5] 

    # for i, device_id in enumerate(device_ids):
    #     torch.cuda.set_device(device_id)
    #     torch.cuda.set_per_process_memory_fraction(memory_fractions[i], device=device_id)
    
    dual_encoder.train_batch(train_data)

    print("-------------------- Saving Model --------------------")
    # Save model 
    torch.save(style_encoder.model.state_dict(), "/home/thao/home/contrastive_aa/res_batch/style_encoder.pt")
    torch.save(content_encoder.encoder.state_dict(), "/home/thao/home/contrastive_aa/res_batch/content_encoder.pt")
    
    style_encoder.model.save_pretrained("/home/thao/home/contrastive_aa/res_batch/style_encoder")
    style_encoder.tokenizer.save_pretrained("/home/thao/home/contrastive_aa/res_batch/style_encoder")

    content_encoder.encoder.save_pretrained("/home/thao/home/contrastive_aa/res_batch/content_encoder")
    content_encoder.tokenizer.save_pretrained("/home/thao/home/contrastive_aa/res_batch/style_encoder")

    torch.save(dual_encoder.state_dict(), "/home/thao/home/contrastive_aa/res_batch/dual_encoder.pt")


    # Test Step
    print("-------------------- Evaluation --------------------")
    save_dir = "/home/thao/home/contrastive_aa/res_batch/result.json"
    style_checkpoint = "/home/thao/home/contrastive_aa/res_batch/style_encoder"
    dual_encoder.test_step(style_checkpoint, train_data, test_data, save_dir)
    

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--batch_size", type=int, default=int(16))
    parser.add_argument("--num_epochs", type=int, default=int(3))
    parser.add_argument("--log_step", type=int, default=10)
    parser.add_argument("--num_iters", type=int, default=100)
    parser.add_argument("--save_dir", type=str)
    main(**vars(parser.parse_args()))
