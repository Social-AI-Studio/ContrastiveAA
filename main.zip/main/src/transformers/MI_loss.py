# Import library
import sys
sys.path.append("/home/thao/home/contrastive_aa/src/")

import torch
import torch.nn as nn

from dataloader import *
from style_encoder import *
from content_encoder import *

class CLUB(nn.Module): 
    def __init__(self, x_samples, y_samples, hidden_size):
        super(CLUB, self).__init__() 
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.x_samples = x_samples
        self.y_samples = y_samples
        self.hidden_size = hidden_size
            
        self.p_mu = nn.Sequential(nn.Linear(self.x_samples.shape[2], self.hidden_size // 2),
                                nn.ReLU(),
                                nn.Linear(self.hidden_size // 2, self.y_samples.shape[2])) 
        
        self.p_logvar = nn.Sequential(nn.Linear(self.x_samples.shape[2], self.hidden_size // 2),
                                    nn.ReLU(),
                                    nn.Linear(self.hidden_size // 2, self.y_samples.shape[2]),
                                    nn.Tanh()) 

    def get_mu_logvar(self, data):
        mu = self.p_mu(data) 
        logvar = self.p_logvar(data) 
        return mu, logvar
    
    def forward(self, x_samples, y_samples): 
        mu, logvar = self.get_mu_logvar(x_samples)
        positive = torch.div(-(mu - y_samples)**2, 2. * torch.exp(logvar))
        
        prediction_1 = mu.unsqueeze(1)          
        y_samples_1 = y_samples.unsqueeze(0)    
        negative = - torch.div(torch.mean((y_samples_1 - prediction_1)**2, dim=1), 2. * torch.exp(logvar))
        res = torch.mean(positive.sum(dim = -1) - negative.sum(dim = -1))
        return res

    def loglikeli(self, x_samples, y_samples):
        mu, logvar = self.get_mu_logvar(x_samples)
        res = torch.mean((-(mu - y_samples)**2 /logvar.exp()-logvar).sum(dim=1), dim=0)
        return res

    def learning_loss(self, x_samples, y_samples):
        res = - self.loglikeli(x_samples, y_samples)
        return res
