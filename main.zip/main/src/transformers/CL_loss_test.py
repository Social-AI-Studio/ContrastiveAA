# Import library
import os
import random
import sys
sys.path.append("/home/thao/home/contrastive_aa/src/")

import json

import datasets
from datasets import load_metric, load_dataset

import pandas as pd

import numpy as np

import transformers
from transformers import (
    BertTokenizer, 
    BertForSequenceClassification, 
    BertModel,
    DataCollatorWithPadding)

import torch
from torch.nn import CosineSimilarity
from torch.utils.data import Dataset, DataLoader

from CL_lossV2 import SupConLoss

# Load pretrained model
checkpoint = "/home/thao/home/contrastive_aa/AA_region_cls"

tokenizer = BertTokenizer.from_pretrained(checkpoint, padding=True, truncation=True)
model = BertModel.from_pretrained(checkpoint)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
output_file = "/home/thao/home/contrastive_aa/test_out/result.json"
model.to(device)

# Load dataset
data_files = {
    "train": "/home/thao/home/contrastive_aa/data/AA_data/AA_cls_train.json", 
    "test": "/home/thao/home/contrastive_aa/data/AA_data/AA_cls_test.json"}

data_collator = DataCollatorWithPadding(
    tokenizer=tokenizer
)

raw_train_dataset = load_dataset("json", data_files=data_files)['train'].shuffle().select(range(1000))
#raw_train_dataset = load_dataset("json", data_files=data_files)['train']
raw_test_dataset = load_dataset("json", data_files=data_files)['test'].shuffle().select(range(1000))
#raw_test_dataset = load_dataset("json", data_files=data_files)['test']

def mean_pooling(model_output, attention_mask):
    token_embeddings = model_output[0] 
    input_mask_expanded = attention_mask.unsqueeze(-1).expand(token_embeddings.size()).float()
    return torch.sum(token_embeddings * input_mask_expanded, 1) / torch.clamp(input_mask_expanded.sum(1), min=1e-9)

# Compute embeddings for each region
def get_embeddings(data=raw_train_dataset, device=device, model = model, tokenizer = tokenizer):
    model.eval()
    
    # Group the data by label
    label_data = {}
    for example in data:
        label = example['label']
        sentence = example['sentence1']
        if label not in label_data:
            label_data[label] = []
        label_data[label].append(sentence)
    
    # Encode each sentence and extract the embeddings
    label_embeddings = []
    sentence_embeddings = []
    for label, sentences in label_data.items():
        sentence_embeddings_label = []
        for sentence in sentences:
            encoded_dict = tokenizer.encode_plus(
                sentence,
                padding=True,
                truncation=True,
                return_tensors='pt'
            )
            # Compute token embeddings
            with torch.no_grad():
                encoded_dict = encoded_dict.to(device)
                model_output = model(**encoded_dict)
            
            # Performing mean pooling
            sentence_embedding = mean_pooling(model_output, encoded_dict['attention_mask'].to(device)) 
            sentence_embeddings_label.append(sentence_embedding)      
            sentence_embeddings.append(sentence_embedding)
            label_embeddings.append(label)

    return torch.stack(sentence_embeddings), label_embeddings

projections, labels = get_embeddings()
targets_ids = [model.config.label2id[label] for label in labels]
targets = torch.tensor(targets_ids)

loss_fn = SupConLoss() 
loss = loss_fn(projections,targets)
print(loss)