import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader

# Import library
import os
import random
import sys
sys.path.append("/home/thao/home/contrastive_aa/src/")

import json
import pickle

import datasets
from datasets import load_metric, load_dataset

import pandas as pd

import numpy as np

import transformers
from transformers import (
    BertTokenizer, 
    BertForSequenceClassification, 
    BertModel,
    DataCollatorWithPadding)

# Load pretrained model
checkpoint = "/home/thao/home/contrastive_aa/AA_test/AA_test_res"
tokenizer = BertTokenizer.from_pretrained(checkpoint, padding=True, truncation=True)
model = BertModel.from_pretrained(checkpoint)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
model.to(device)

# Load dataset
data_files = {
    "train": "/home/thao/home/contrastive_aa/data/AA_data/AA_cls_train.json", 
    "test": "/home/thao/home/contrastive_aa/data/AA_data/AA_cls_test.json"}

#raw_train_dataset = load_dataset("json", data_files=data_files)['train'].shuffle().select(range(10))
raw_train_dataset = load_dataset("json", data_files=data_files)['train']
#raw_test_dataset = load_dataset("json", data_files=data_files)['test'].shuffle().select(range(10))
raw_test_dataset = load_dataset("json", data_files=data_files)['test']

def mean_pooling(model_output, attention_mask):
    token_embeddings = model_output[0] 
    input_mask_expanded = attention_mask.unsqueeze(-1).expand(token_embeddings.size()).float()
    return torch.sum(token_embeddings * input_mask_expanded, 1) / torch.clamp(input_mask_expanded.sum(1), min=1e-9)

def get_embeddings(data=raw_train_dataset, device=device, model = model, tokenizer = tokenizer):
    model.eval()
    
    # Group the data by label
    label_data = {}
    for example in data:
        label = example['label']
        sentence = example['sentence1']
        if label not in label_data:
            label_data[label] = []
        label_data[label].append(sentence)
    
    # Encode each sentence and extract the embeddings
    label_embeddings = []
    sentence_embeddings = []
    for label, sentences in label_data.items():
        sentence_embeddings_label = []
        for sentence in sentences:
            encoded_dict = tokenizer.encode_plus(
                sentence,
                padding=True,
                truncation=True,
                return_tensors='pt'
            )
            # Compute token embeddings
            with torch.no_grad():
                encoded_dict = encoded_dict.to(device)
                model_output = model(**encoded_dict)
            
            # Performing mean pooling
            sentence_embedding = mean_pooling(model_output, encoded_dict['attention_mask'].to(device)) 
            sentence_embeddings_label.append(sentence_embedding)      
            sentence_embeddings.append(sentence_embedding)
            label_embeddings.append(label)

    return torch.stack(sentence_embeddings), label_embeddings

class AuthorEncoder(nn.Module):
    """ Speaker embeddings"""
    def __init__(self, num_layers=2, dim_input=768, dim_hidden=768, dim_emb=256):
        super(AuthorEncoder, self).__init__()
        self.lstm = nn.LSTM(input_size=dim_input, hidden_size=dim_hidden, 
                            num_layers=num_layers, batch_first=True)  
        self.fc = nn.Linear(dim_hidden, dim_emb)
        
    def forward(self, x):
        self.lstm.flatten_parameters()            
        lstm_out, _ = self.lstm(x)
        embeddings = self.fc(lstm_out[:,-1,:])

        norm = embeddings.norm(p=2, dim=-1, keepdim=True) 
        embeds_normalized = embeddings.div(norm)
        return embeds_normalized


encoder = AuthorEncoder().eval().to(device)
embs_list =[]

projections, labels = get_embeddings()
embs = encoder(projections).tolist()
print(len(embs))

out_dir_train = "/home/thao/home/contrastive_aa/data/AA_data/author_train_embs.json"
out_dir_test = "/home/thao/home/contrastive_aa/data/AA_data/author_test_embs.json"
with open(out_dir_train, 'w') as f:
    json.dump(embs_list, f)


