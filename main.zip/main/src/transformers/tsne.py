# Import library
import sys
sys.path.append("/home/thao/home/contrastive_aa/src/")
import transformers
from transformers import (
    BertTokenizer, 
    AutoConfig,
    BertModel,)
import torch

import matplotlib.pyplot as plt

from sklearn.manifold import TSNE
import numpy as np
from dataloader import *
import seaborn as sns
import random
from PIL import Image
from matplotlib.font_manager import FontProperties
from ranking_eva import *
from heatmap import *

def get_embs(data, checkpoint='bert-base-uncased'):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    tokenizer = BertTokenizer.from_pretrained(checkpoint)
    model = BertModel.from_pretrained(checkpoint)
    model.to(device)
    model.eval()

    input_data = [sentence['sentence1'] for sentence in data]
    input_label = [label['label'] for label in data]
    labels = [str(i) for i in input_label]
    # labels = [model.config.label2id[label] for label in labels]
    
    embeddings_data = []
    for idx, text in enumerate(input_data):
        encoded_dict = tokenizer.encode_plus(
            text,
            truncation=True,
            padding="max_length",
            return_tensors='pt',
        )

        with torch.no_grad():
            encoded_dict = encoded_dict.to(device)
            model_output = model(**encoded_dict)
            embeddings = model_output.last_hidden_state
            embeddings_data.append(embeddings)

    embeddings_data =torch.cat(embeddings_data, dim=0)
    return embeddings_data,labels

def process_data(datas, num=50):
    selected_data = {}
    samples = []
    input_labels = set([data['label'] for data in datas])
    labels = [str(i) for i in input_labels]

    for label in labels:
        selected_data[label] = random.sample([data for data in datas if str(data['label']) == str(label)], num)

    for label, data_list in selected_data.items():
        for data in data_list:
            samples.append(data)
    return samples

def tsne_plot(embeddings_data, labels, save_dr, title, author=False):
    tsne = TSNE(n_components=2, random_state=42)
    embeddings_data_2d = embeddings_data.view(embeddings_data.size(0), -1).cpu().numpy()
    embeddings_tsne = tsne.fit_transform(embeddings_data_2d)

    plt.figure(figsize=(10, 8))
    sns.scatterplot(
        x=embeddings_tsne[:, 0],
        y=embeddings_tsne[:, 1],
        hue=labels,
        palette='tab10',
        legend='full',
        # alpha=0.7,
        edgecolor='none'
    )
    title_font = FontProperties(family='Times New Roman', weight='bold', size=25)
    plt.title(title, fontproperties=title_font) 
    # plt.title(title, fontsize=25, fontweight='bold')
    # plt.legend(fontsize=30, prop={'weight': 'bold'})
    legend_font = FontProperties(weight='bold', size=27)
    # plt.legend(fontsize=22, prop=legend_font)
    plt.legend(fontsize=27, prop=legend_font)

    plt.xticks([])
    plt.yticks([])

    if author == True:
        plt.legend([], frameon=False)

    dpi = 600
    plt.tight_layout()
    plt.savefig(save_dr, format="pdf", dpi=dpi)



def get_embeddings(sentence, checkpoint='bert-base-uncased'):
    tokenizer = BertTokenizer.from_pretrained(checkpoint)
    model = BertModel.from_pretrained(checkpoint)

    tokens = tokenizer.tokenize(sentence)
    token_ids = tokenizer.convert_tokens_to_ids(tokens)

    inputs = tokenizer.encode(sentence, return_tensors='pt')
    outputs = model(inputs)

    word_embeddings = outputs.last_hidden_state.squeeze(0)
    sentence_embedding = word_embeddings.mean(dim=0)

    return tokens, token_ids, word_embeddings, sentence_embedding


def draw_heatmap(similarities, tokens, save_dr):
    sns.set()
    plt.figure(figsize=(8, 6))
    ax = sns.heatmap(similarities.reshape(1, -1), cmap="YlGnBu", annot=False, fmt=".2f", xticklabels=['cls'] + tokens + ['sep'], yticklabels=False)
    ax.set_title("Word Similarity with Sentence", fontsize=25, fontweight="bold")
    ax.set_xticklabels(ax.get_xticklabels(), fontsize=23, fontweight="bold", rotation=85) 
    dpi = 600
    plt.tight_layout()
    plt.savefig(save_dr, format="pdf", dpi=dpi)

checkpoint = "/home/thao/home/contrastive_aa/AA_region_batchV6"
save_dr = "/home/thao/home/contrastive_aa/visusualization_emb/heatmap3.pdf"
# data = "try some coconut coffee hot_beverage USER Cong Caphe HTTPURL"
data = "Pusing lah kot mana pun , no one else is calling it democratic . Except PN of cours"
# data = "So much things on my mind rn ! Inshallah all goes wel"
# data ="isit Indonesian #Booth in Ly Thao To Park , DATE"

get_embeddings(data, checkpoint)

tokens, token_ids, word_embeddings, sentence_embedding = get_embeddings(data)

# Use the tokens, word_embeddings, and sentence_embedding obtained previously
similarities = calculate_similarity(word_embeddings, sentence_embedding.detach().numpy())
print(tokens)
draw_heatmap(similarities, tokens, save_dr)


# data_files = {
#     "train": "/home/thao/home/contrastive_aa/data/AA_data/AA_cls_train.json", 
#     "test": "/home/thao/home/contrastive_aa/data/AA_data/AA_cls_test.json"}

# region_train_data, region_test_data = get_dataset(data_files=data_files)
# region_samples = process_data(region_train_data, 500)

# region_checkpoint2 = "/home/thao/home/contrastive_aa/AA_region_batchV6"
# region_checkpoint1 = "/home/thao/home/contrastive_aa/AA_test_res"

# region_1 = "/home/thao/home/contrastive_aa/visusualization_emb/tsne_region_1_10.pdf"
# region_2 = "/home/thao/home/contrastive_aa/visusualization_emb/tsne_region_2_10.pdf"
# region_3 = "/home/thao/home/contrastive_aa/visusualization_emb/tsne_region_3_10.pdf"

# title_region_1 = "Region-level Style Embeddings - Scratch"
# title_region_2 = "Region-level Style Embeddings - Contra"
# title_region_3 = "Region-level Style Embeddings - Contra&Dist"

# region_embeddings_data, labels = get_embs(region_samples)
# tsne_plot(region_embeddings_data, labels, region_1, title_region_1)

# region_embeddings_data1, labels1 = get_embs(region_samples, checkpoint= region_checkpoint1)
# tsne_plot(region_embeddings_data1, labels1, region_2, title_region_2)

# region_embeddings_data2, labels2 = get_embs(region_samples, checkpoint= region_checkpoint2)
# tsne_plot(region_embeddings_data2, labels2, region_3, title_region_3)



# Author plot
# train_file = "/home/thao/home/contrastive_aa/data/CCAT50/processed/CCAT50_train.csv"
# test_file = "/home/thao/home/contrastive_aa/data/CCAT50/processed/CCAT50_AA_test.csv"
# author_train_data = get_csv_dataset(train_file)
# author_test_data = get_csv_dataset(test_file)
# author_train_data = author_train_data['train']
# author_test_data = author_test_data['train']

# author_checkpoint1 = "/home/thao/home/contrastive_aa/AA_author"
# author_checkpoint2 = "/home/thao/home/contrastive_aa/disentangle_res_authorV2/style_encoder"

# author_1 = "/home/thao/home/contrastive_aa/visusualization_emb/tsne_author_1_10.pdf"
# author_2 = "/home/thao/home/contrastive_aa/visusualization_emb/tsne_author_2_10.pdf"
# author_3 = "/home/thao/home/contrastive_aa/visusualization_emb/tsne_author_3_10.pdf"

# title_author_1 = "Author-level Style Embeddings - Scratch"
# title_author_2 = "Author-level Style Embeddings - Contra"
# title_author_3 = "Author-level Style Embeddings - Contra&Dist"

# # author_embeddings_data, labels = get_embs(author_train_data)
# # tsne_plot(author_embeddings_data, labels, author_1, title_author_1, author=True)

# # author_embeddings_data1, labels1 = get_embs(author_train_data, author_checkpoint1)
# # tsne_plot(author_embeddings_data1, labels1, author_3, title_author_3, author=True)

# author_embeddings_data2, labels2 = get_embs(author_test_data, author_checkpoint2)
# tsne_plot(author_embeddings_data2, labels2, author_2, title_author_2, author=True)



