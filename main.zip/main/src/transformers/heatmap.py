import sys
sys.path.append("/home/thao/home/contrastive_aa/src/")
import torch
from transformers import BertTokenizer, BertModel
from torch.nn.functional import cosine_similarity
import numpy as np


# def get_embeddings(sentence, checkpoint='bert-base-uncased'):
#     tokenizer = BertTokenizer.from_pretrained(checkpoint)
#     model = BertModel.from_pretrained(checkpoint)

#     tokens = tokenizer.tokenize(sentence)
#     token_ids = tokenizer.convert_tokens_to_ids(tokens)

#     inputs = tokenizer.encode(sentence, return_tensors='pt')
#     outputs = model(inputs)

#     word_embeddings = outputs.last_hidden_state.squeeze(0)
#     sentence_embedding = word_embeddings.mean(dim=0)

#     return tokens, token_ids, word_embeddings, sentence_embedding


# checkpoint = "/home/thao/home/contrastive_aa/AA_region_batchV6"
# data = "@USER thank u naa"

# tokens, token_ids, word_embeddings, sentence_embedding = get_embeddings(data)

# # Access the embeddings for each word
# for token, embedding in zip(tokens, word_embeddings):
#     print(f"Token: {token}, Embedding: {embedding}")

# # Access the embedding for the entire sentence
# print(f"Sentence Embedding: {sentence_embedding}")


def calculate_similarity(word_embeddings, sentence_embedding):
    word_embeddings = torch.tensor(word_embeddings)
    sentence_embedding = torch.tensor(sentence_embedding)
    similarities = cosine_similarity(word_embeddings, sentence_embedding.unsqueeze(0))
    return similarities.flatten()



# def calculate_cosine_similarity(data, checkpoint="bert-base-uncased"):
#     device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
#     tokenizer = BertTokenizer.from_pretrained(checkpoint)
#     model = BertModel.from_pretrained(checkpoint)
#     model.to(device)
#     model.eval()

#     token_list = [] 

#     embeddings_data = []
#     token_embeddings_data = []

#     cosine_similarities = []  

#     for idx, text in enumerate(data):
#         encoded_dict = tokenizer(
#             text,
#             truncation=True,
#             padding="max_length",
#             is_split_into_words=True,
#             return_tensors='pt',
#         )

#         with torch.no_grad():
#             encoded_dict = encoded_dict.to(device)
#             model_output = model(**encoded_dict)
#             embeddings = model_output.last_hidden_state
#             embeddings_data.append(embeddings)

#             token_embeddings = embeddings.squeeze(0)
#             token_embeddings_data.append(token_embeddings)
        
#             tokens = tokenizer.convert_ids_to_tokens(encoded_dict['input_ids'].squeeze().tolist())
#             token_list.append(tokens)

#             # tokens = tokenizer.convert_ids_to_tokens(encoded_dict['input_ids'].squeeze().tolist())
#             # token_list.append(tokens)

#             # Calculate cosine similarity between each token and the sentence embedding
#             sentence_embedding = torch.mean(token_embeddings, dim=0)
#             token_cosine_similarities = cosine_similarity(token_embeddings, sentence_embedding.unsqueeze(0), dim=1)
#             cosine_similarities.append(token_cosine_similarities)

#     embeddings_data = torch.cat(embeddings_data, dim=0)
#     token_embeddings_data = torch.cat(token_embeddings_data, dim=0)
#     cosine_similarities = torch.cat(cosine_similarities, dim=0)
#     cosine_sim_matrix = cosine_similarities.cpu().numpy().reshape(len(data), -1)
#     return token_list, cosine_sim_matrix




# checkpoint = "/home/thao/home/contrastive_aa/AA_region_batchV6"
# data = "@USER thank u naa"
# # calculate_cosine_similarity(data, checkpoint)
# token_list, cosine_similarity = calculate_cosine_similarity(data, checkpoint)
# print(cosine_similarity.shape)
# print(token_list)