# Import library
import sys
sys.path.append("/home/thao/home/contrastive_aa/src/")
import json
import datasets
from datasets import load_metric
import transformers
from transformers import (
    BertTokenizer, 
    AutoConfig,
    BertModel,)
import torch
from torch.utils.data import DataLoader
from dataloader import *

class RegionComparison():
    def __init__(self, 
                 checkpoint, 
                 train_data,
                 test_data, 
                 output_file = "/home/thao/home/contrastive_aa/disentangle_res/result.json"):
        self.checkpoint = checkpoint
        self.model =  BertModel.from_pretrained(self.checkpoint)
        self.tokenizer = BertTokenizer.from_pretrained(self.checkpoint, padding=True, truncation=True)
        self.train_data = train_data
        self.test_data = test_data
        self.output_file = output_file
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.model.to(self.device)

    def mean_pooling(self, model_output, attention_mask):
        token_embeddings = model_output[0] 
        input_mask_expanded = attention_mask.unsqueeze(-1).expand(token_embeddings.size()).float()
        return torch.sum(token_embeddings * input_mask_expanded, 1) / torch.clamp(input_mask_expanded.sum(1), min=1e-9)

    # Compute and return average embeddings for each region
    def get_average_embeddings(self, data):
        self.model.eval()

        device = self.device
        tokenizer = self.tokenizer
        model = self.model
        
        # Group the data by label
        label_data = {}
        for example in data:
            label = example['label']
            sentence = example['sentence1']
            if label not in label_data:
                label_data[label] = []
            label_data[label].append(sentence)
        
        # Encode each sentence and extract the embeddings
        label_embeddings = {}
        for label, sentences in label_data.items():
            sentence_embeddings = []
            for sentence in sentences:
                encoded_dict = tokenizer.encode_plus(
                    sentence,
                    padding=True,
                    truncation=True,
                    return_tensors='pt'
                )
                # Compute token embeddings
                with torch.no_grad():
                    encoded_dict = encoded_dict.to(device)
                    model_output = model(**encoded_dict)
                
                # Performing mean pooling
                sentence_embedding = self.mean_pooling(model_output, encoded_dict['attention_mask'].to(device))       
                sentence_embeddings.append(sentence_embedding)

            label_embeddings[label] = torch.stack(sentence_embeddings)

        mean_embeddings = {}
        for label, embeddings in label_embeddings.items():
            mean_embedding = torch.mean(embeddings, dim=0)
            mean_embeddings[label] = mean_embedding

        return mean_embeddings

    # Compute and return the ranking for the regions based on the input data
    def compare_to_regions(self, train_data, test_data):
        input_data = test_data['sentence1']

        input_embeddings = []
        for idx, text in enumerate(input_data):
            encoded_dict = self.tokenizer.encode_plus(
                text,
                truncation=True,
                padding="max_length",
                return_tensors='pt',
            )

            # Compute token embeddings
            with torch.no_grad():
                encoded_dict = encoded_dict.to(self.device)
                model_output = self.model(**encoded_dict)
            
            # Performing mean pooling
            sentence_embeddings = self.mean_pooling(model_output, encoded_dict['attention_mask'])       
            input_embeddings.append(sentence_embeddings)

        region_embeddings = self.get_average_embeddings(train_data)
        region_embeddings = {label: torch.tensor(embedding).to(self.device) for label, embedding in region_embeddings.items()}

        # Compute the similarity between the embeddings of the input data and each region
        similarities = []
        for input_embedding in input_embeddings:
            input_embedding = input_embedding.to(self.device)
            input_embedding = torch.reshape(input_embedding, (1, -1))

            input_similarity = {}

            for label, region_embedding in region_embeddings.items():
                region_embedding = region_embedding.view(1, -1)  # Reshape to (1, num_features)
                similarity = torch.nn.CosineSimilarity(dim=-1)
                input_similarity[label] = similarity(region_embedding, input_embedding).item()
            
            # Sort the labels by similarity score for each input embedding
            sorted_labels = dict(sorted(input_similarity.items(), key=lambda x: x[1], reverse=True))
            similarities.append(sorted_labels)
        
        results_list = []
        for i in range(len(test_data)):
            result = {}
            result['label'] = test_data['label'][i]

            input_text = test_data['sentence1'][i]
            result['sentence'] = input_text

            similarity_scores = similarities[i]
            result['similarity_scores'] = similarity_scores
            results_list.append(result)
        
        return results_list
    
    def get_region_embs(self, train_data, test_data):
        input_data = test_data['sentence1']

        input_embeddings = []
        for idx, text in enumerate(input_data):
            encoded_dict = self.tokenizer.encode_plus(
                text,
                truncation=True,
                padding="max_length",
                return_tensors='pt',
            )

            # Compute token embeddings
            with torch.no_grad():
                encoded_dict = encoded_dict.to(self.device)
                model_output = self.model(**encoded_dict)
            
            # Performing mean pooling
            sentence_embeddings = self.mean_pooling(model_output, encoded_dict['attention_mask'])       
            input_embeddings.append(sentence_embeddings)

        region_embeddings = self.get_average_embeddings(train_data)
        region_embeddings = {label: torch.tensor(embedding).to(self.device) for label, embedding in region_embeddings.items()}
        return input_embeddings

    def extract_labels_predictions(self, results_list, key_index=0):
        labels = []
        predictions = []
        for result in results_list:
            labels.append(result['label'])
            score_dict = result['similarity_scores']
            key = list(score_dict.keys())[key_index]
            predictions.append(key)
        
        predictions = [str(i) for i in predictions]
        labels = [str(i) for i in labels]

        predictions = [self.model.config.label2id[label] for label in predictions]
        labels = [self.model.config.label2id[label] for label in labels]

        return labels, predictions
    
    def compute_top_k(self, top_k):
        result_list = self.compare_to_regions(self.train_data, self.test_data)
        labels = []
        predictions = []

        for result in result_list:
            labels.append(result['label'])
            score_dict = result['similarity_scores']
            keys = list(score_dict.keys())[:top_k]
            # print(keys)
            keys = [str(i) for i in keys]
            keys = [self.model.config.label2id[key] for key in keys]
            predictions.append(keys)
        # print(labels)
        predictions = [str(i) for i in predictions]
        labels = [str(i) for i in labels]
        labels = [self.model.config.label2id[label] for label in labels]
        labels = [str(i) for i in labels]

        total_examples = len(labels)
        correct_predictions = 0

        for label, prediction in zip(labels, predictions):
            if label in prediction[:top_k]:
                correct_predictions += 1

        top_k_accuracy = round((correct_predictions / total_examples),3)
        print(f"{top_k + 1} accuracy: {top_k_accuracy}")
        return top_k_accuracy
       
        
    def compute_metrics(self): 
        result_list = self.compare_to_regions(self.train_data, self.test_data)
        references, predictions = self.extract_labels_predictions(result_list)
        predictions = [str(i) for i in predictions]
        references = [str(i) for i in references]

        metric_names = ["accuracy", "precision", "recall", "f1"]
        metrics = {metric_name: load_metric(metric_name) for metric_name in metric_names}
        results = {}
        for metric_name, metric in metrics.items():
            if metric_name == "accuracy":
                score = metric.compute(predictions=predictions, references=references)
            else:
                try:
                    score = metric.compute(predictions=predictions, references=references, average="weighted")
                except ValueError:
                    score = metric.compute(predictions=predictions, references=references, average=None)

            print(f"{metric_name} score: {score}")
            results[metric_name] = score
        return results


