# import torch
# import torch.nn as nn

# from math import log

# class SupConLoss(nn.Module):
#     def __init__(self, temperature=0.07):
#         """
#         Implementation of the loss described in the paper Supervised Contrastive Learning :
#         https://arxiv.org/abs/2004.11362
#         :param temperature: int
#         """
#         super(SupConLoss, self).__init__()
#         self.temperature = temperature
#         self.cos = nn.CosineSimilarity(dim=-1)

#     def forward(self, projections, targets):
#         """
#         :param projections: torch.Tensor, shape [batch_size, projection_dim]
#         :param targets: torch.Tensor, shape [batch_size]
#         :return: torch.Tensor, scalar
#         """
#         device = torch.device("cuda") if projections.is_cuda else torch.device("cpu")

#         # Compute similarity matrix
#         ## dot_product_tempered = torch.mm(projections, projections.T) / self.temperature
#         dot_product_tempered = self.cos(projections.unsqueeze(1), projections.unsqueeze(0)) / self.temperature

#         ## Minus max for numerical stability with exponential. Same done in cross entropy. Epsilon added to avoid log(0)
#         exp_dot_tempered = (
#             torch.exp(dot_product_tempered - torch.max(dot_product_tempered, dim=1, keepdim=True)[0]) + 1e-5
#         )

#         # Identify positive pairs for each anchor sample
#         mask_similar_class = (targets.unsqueeze(1).repeat(1, targets.shape[0]) == targets).to(device)
#         mask_anchor_out = (1 - torch.eye(exp_dot_tempered.shape[0])).to(device)
#         mask_combined = mask_similar_class * mask_anchor_out   

#         # Compute number of relevant positive samples for each anchor sample
#         cardinality_per_samples = torch.sum(mask_combined, dim=1)

#         ## to avoid nan value of the loss if there is only one sample of a category  on the batch
#         for i in range(cardinality_per_samples.size(0)):
#             if cardinality_per_samples[i]==0:
#                 cardinality_per_samples[i] = 1

#         # Compute log probability of positive pairs
#         log_prob = -torch.log(exp_dot_tempered / (torch.sum(exp_dot_tempered * mask_anchor_out, dim=1, keepdim=True)))
#         supervised_contrastive_loss_per_sample = torch.sum(log_prob * mask_combined, dim=1) / cardinality_per_samples
#         supervised_contrastive_loss = torch.mean(supervised_contrastive_loss_per_sample)

#         # Identify negative pairs for each anchor sample
#         mask_diff_class = (targets.unsqueeze(1).repeat(1, targets.shape[0]) != targets).to(device)
#         mask_neg_combined = mask_diff_class * mask_anchor_out
        
#         # Compute number of relevant negative samples for each anchor sample
#         cardinality_neg_per_samples = torch.sum(mask_neg_combined, dim=1)
#         for i in range(cardinality_neg_per_samples.size(0)):
#             if cardinality_neg_per_samples[i]==0:
#                 cardinality_neg_per_samples[i] = 1
                
#         # Compute exponentiated dot product of negative pairs
#         exp_dot_tempered_neg = exp_dot_tempered * mask_diff_class
#         # Compute the log probability of the selected negative samples and average the resulting values across each anchor sample
#         log_prob_neg = -torch.log(
#             (exp_dot_tempered_neg / torch.sum(exp_dot_tempered_neg * mask_anchor_out, dim=1, keepdim=True)))
        
#         supervised_contrastive_loss_neg_per_sample = torch.sum(log_prob_neg * mask_neg_combined, dim=1) / cardinality_neg_per_samples
#         supervised_contrastive_loss_neg = torch.mean(supervised_contrastive_loss_neg_per_sample)

        
#         total_loss = supervised_contrastive_loss + supervised_contrastive_loss_neg
#         return total_loss


# class SupConLoss(nn.Module):
#     def __init__(self, temperature=0.07):
#         """
#         Implementation of the loss described in the paper Supervised Contrastive Learning :
#         https://arxiv.org/abs/2004.11362
#         :param temperature: int
#         """
#         super(SupConLoss, self).__init__()
#         self.temperature = temperature
#         self.cos = nn.CosineSimilarity(dim=-1)

#     def forward(self, projections, targets):
#         """
#         :param projections: torch.Tensor, shape [batch_size, projection_dim]
#         :param targets: torch.Tensor, shape [batch_size]
#         :return: torch.Tensor, scalar
#         """
#         device = torch.device("cuda") if projections.is_cuda else torch.device("cpu")

#         # Compute similarity matrix
#         ## dot_product_tempered = torch.mm(projections, projections.T) / self.temperature
#         dot_product_tempered = self.cos(projections.unsqueeze(1), projections.unsqueeze(0)) / self.temperature

#         # Compute softmax probabilities over all pairs (positive and negative)
#         ## Minus max for numerical stability with exponential. Same done in cross entropy. Epsilon added to avoid log(0)
#         exp_dot_tempered = (
#             torch.exp(dot_product_tempered - torch.max(dot_product_tempered, dim=1, keepdim=True)[0]) + 1e-5
#         )

#         # Identify positive pairs for each anchor sample
#         mask_similar_class = (targets.unsqueeze(1).repeat(1, targets.shape[0]) == targets).to(device)
#         mask_anchor_out = (1 - torch.eye(exp_dot_tempered.shape[0])).to(device)
#         mask_combined_pos = mask_similar_class * mask_anchor_out

#         mask_diff_class = (targets.unsqueeze(1).repeat(1, targets.shape[0]) != targets).to(device)
#         mask_combined_neg = mask_diff_class * mask_anchor_out

#         exp_sum = torch.sum(exp_dot_tempered * mask_anchor_out, dim=1, keepdim=True)
#         probabilities = exp_dot_tempered / exp_sum

#         # Compute number of relevant positive and negative samples for each anchor sample
#         cardinality_positive = torch.sum(mask_combined_pos, dim=1, keepdim=True)
#         cardinality_negative = torch.sum(mask_combined_neg, dim=1, keepdim=True)

#         ## to avoid nan value of the loss if there is only one sample of a category  on the batch
#         for i in range(cardinality_positive.size(0)):
#             if cardinality_positive[i]==0:
#                 cardinality_positive[i] = 1

#         for i in range(cardinality_negative.size(0)):
#             if cardinality_negative[i]==0:
#                 cardinality_negative[i] = 1

#         # Compute log probability of positive and negative pairs
#         log_prob_positive = -torch.log(probabilities) * mask_combined_pos
#         log_prob_negative = -torch.log(probabilities) * mask_combined_neg

#         # Compute supervised contrastive loss
#         supervised_contrastive_loss_positive = torch.sum(log_prob_positive, dim=1) / cardinality_positive
#         supervised_contrastive_loss_negative = torch.sum(log_prob_negative, dim=1) / cardinality_negative

#         # supervised_contrastive_loss = torch.mean(torch.cat([supervised_contrastive_loss_positive, supervised_contrastive_loss_negative]))
#         total_loss = torch.mean(supervised_contrastive_loss_positive - supervised_contrastive_loss_negative)

#         return total_loss

# import torch
# import torch.nn as nn

# from math import log    

# class SupConLoss(nn.Module):
#     def __init__(self, temperature=0.07, hard_negative_ratio=0.5):
#         """
#         Implementation of the loss described in the paper Supervised Contrastive Learning :
#         https://arxiv.org/abs/2004.11362
#         :param temperature: int
#         """
#         super(SupConLoss, self).__init__()
#         self.temperature = temperature
#         self.cos = nn.CosineSimilarity(dim=-1)
#         self.hard_negative_ratio = hard_negative_ratio

#     def forward(self, projections, targets):
#         """
#         :param projections: torch.Tensor, shape [batch_size, projection_dim]
#         :param targets: torch.Tensor, shape [batch_size]
#         :return: torch.Tensor, scalar
#         """
#         device = torch.device("cuda") if projections.is_cuda else torch.device("cpu")

#         # Compute similarity matrix
#         ## dot_product_tempered = torch.mm(projections, projections.T) / self.temperature
#         dot_product_tempered = self.cos(projections.unsqueeze(1), projections.unsqueeze(0)) / self.temperature

#         # Compute softmax probabilities over all pairs (positive and negative)
#         ## Minus max for numerical stability with exponential. Same done in cross entropy. Epsilon added to avoid log(0)
#         exp_dot_tempered = (
#             torch.exp(dot_product_tempered - torch.max(dot_product_tempered, dim=1, keepdim=True)[0]) + 1e-5
#         )

#         # Identify positive pairs for each anchor sample
#         mask_similar_class = (targets.unsqueeze(1).repeat(1, targets.shape[0]) == targets).to(device)
#         mask_anchor_out = (1 - torch.eye(exp_dot_tempered.shape[0])).to(device)
#         mask_combined_pos = mask_similar_class * mask_anchor_out

#         mask_diff_class = (targets.unsqueeze(1).repeat(1, targets.shape[0]) != targets).to(device)
#         mask_combined_neg = mask_diff_class * mask_anchor_out

#         exp_sum = torch.sum(exp_dot_tempered * mask_anchor_out, dim=1, keepdim=True)
#         probabilities = exp_dot_tempered / exp_sum

#         # Compute number of relevant positive and negative samples for each anchor sample
#         cardinality_positive = torch.sum(mask_combined_pos, dim=1, keepdim=True)
#         cardinality_negative = torch.sum(mask_combined_neg, dim=1, keepdim=True)

#         ## to avoid nan value of the loss if there is only one sample of a category  on the batch
#         for i in range(cardinality_positive.size(0)):
#             if cardinality_positive[i]==0:
#                 cardinality_positive[i] = 1

#         for i in range(cardinality_negative.size(0)):
#             if cardinality_negative[i]==0:
#                 cardinality_negative[i] = 1

#         # Compute log probability of positive and negative pairs
#         log_prob_positive = -torch.log(probabilities) * mask_combined_pos
#         log_prob_negative = -torch.log(probabilities) * mask_combined_neg

#         # Online hard negative mining
#         num_hard_negatives = int(self.hard_negative_ratio * projections.size(0))
#         _, negative_indices = torch.topk(log_prob_negative, k=num_hard_negatives, dim=1)
#         mask_hard_negatives = torch.zeros_like(log_prob_negative).scatter(1, negative_indices, 1)
#         log_prob_negative = log_prob_negative * mask_hard_negatives.to(device)

#         # Compute supervised contrastive loss
#         supervised_contrastive_loss_positive = torch.sum(log_prob_positive, dim=1) / cardinality_positive
#         supervised_contrastive_loss_negative = torch.sum(log_prob_negative, dim=1) / num_hard_negatives

#         # supervised_contrastive_loss = torch.mean(torch.cat([supervised_contrastive_loss_positive, supervised_contrastive_loss_negative]))
#         total_loss = torch.mean(supervised_contrastive_loss_positive - supervised_contrastive_loss_negative)

#         return total_loss


# import torch
# import torch.nn as nn

# from math import log    

# class SupConLoss(nn.Module):
#     def __init__(self, temperature=0.07, margin=0.2):
#         """
#         Implementation of the loss described in the paper Supervised Contrastive Learning :
#         https://arxiv.org/abs/2004.11362
#         :param temperature: int
#         """
#         super(SupConLoss, self).__init__()
#         self.temperature = temperature
#         self.cos = nn.CosineSimilarity(dim=-1)
#         self.margin = margin

#     def forward(self, projections, targets):
#         """
#         :param projections: torch.Tensor, shape [batch_size, projection_dim]
#         :param targets: torch.Tensor, shape [batch_size]
#         :return: torch.Tensor, scalar
#         """
#         device = torch.device("cuda") if projections.is_cuda else torch.device("cpu")

#         # Compute similarity matrix
#         ## dot_product_tempered = torch.mm(projections, projections.T) / self.temperature
#         dot_product_tempered = self.cos(projections.unsqueeze(1), projections.unsqueeze(0)) / self.temperature

#         # Compute softmax probabilities over all pairs (positive and negative)
#         ## Minus max for numerical stability with exponential. Same done in cross entropy. Epsilon added to avoid log(0)
#         exp_dot_tempered = (
#             torch.exp(dot_product_tempered - torch.max(dot_product_tempered, dim=1, keepdim=True)[0]) + 1e-5
#         )

#         # Identify positive pairs for each anchor sample
#         mask_similar_class = (targets.unsqueeze(1).repeat(1, targets.shape[0]) == targets).to(device)
#         mask_anchor_out = (1 - torch.eye(exp_dot_tempered.shape[0])).to(device)
#         mask_combined_pos = mask_similar_class * mask_anchor_out

#         mask_diff_class = (targets.unsqueeze(1).repeat(1, targets.shape[0]) != targets).to(device)
#         mask_combined_neg = mask_diff_class * mask_anchor_out

#         exp_sum = torch.sum(exp_dot_tempered * mask_anchor_out, dim=1, keepdim=True)
#         probabilities = exp_dot_tempered / (exp_sum + 1e-5) 

#         # Compute number of relevant positive and negative samples for each anchor sample
#         cardinality_positive = torch.sum(mask_combined_pos, dim=1, keepdim=True)
#         cardinality_negative = torch.sum(mask_combined_neg, dim=1, keepdim=True)

#         ## to avoid nan value of the loss if there is only one sample of a category  on the batch
#         for i in range(cardinality_positive.size(0)):
#             if cardinality_positive[i]==0:
#                 cardinality_positive[i] = 1

#         for i in range(cardinality_negative.size(0)):
#             if cardinality_negative[i]==0:
#                 cardinality_negative[i] = 1

#         # Compute log probability of positive and negative pairs
#         log_prob_positive = -torch.log(probabilities) * mask_combined_pos
#         log_prob_negative = -torch.log(probabilities) * mask_combined_neg

#         # Compute supervised contrastive loss
#         pos = torch.sum(log_prob_positive, dim=1) / cardinality_positive
#         neg = torch.sum(log_prob_negative, dim=1) / cardinality_negative

#         #total_loss = torch.mean(supervised_contrastive_loss_positive - supervised_contrastive_loss_negative)
#         total_loss = torch.mean(torch.clamp(pos - neg + self.margin, min=0))
#         return total_loss



# 
import torch
import torch.nn as nn

from math import log    

class SupConLoss(nn.Module):
    def __init__(self, temperature=0.07, margin=0.2):
        """
        Implementation of the loss described in the paper Supervised Contrastive Learning :
        https://arxiv.org/abs/2004.11362
        :param temperature: int
        """
        super(SupConLoss, self).__init__()
        self.temperature = temperature
        self.cos = nn.CosineSimilarity(dim=-1)
        self.margin = margin

    def forward(self, projections, targets):
        """
        :param projections: torch.Tensor, shape [batch_size, projection_dim]
        :param targets: torch.Tensor, shape [batch_size]
        :return: torch.Tensor, scalar
        """
        device = torch.device("cuda") if projections.is_cuda else torch.device("cpu")

        # Compute similarity matrix
        ## dot_product_tempered = torch.mm(projections, projections.T) / self.temperature
        dot_product_tempered = self.cos(projections.unsqueeze(1), projections.unsqueeze(0)) / self.temperature

        # Compute softmax probabilities over all pairs (positive and negative)
        ## Minus max for numerical stability with exponential. Same done in cross entropy. Epsilon added to avoid log(0)
        exp_dot_tempered = (
            torch.exp(dot_product_tempered - torch.max(dot_product_tempered, dim=1, keepdim=True)[0]) + 1e-5
        )

        # Identify positive pairs for each anchor sample
        mask_similar_class = (targets.unsqueeze(1).repeat(1, targets.shape[0]) == targets).to(device)
        mask_anchor_out = (1 - torch.eye(exp_dot_tempered.shape[0])).to(device)
        mask_combined_pos = mask_similar_class * mask_anchor_out

        mask_diff_class = (targets.unsqueeze(1).repeat(1, targets.shape[0]) != targets).to(device)
        mask_combined_neg = mask_diff_class * mask_anchor_out

        exp_sum = torch.sum(exp_dot_tempered * mask_anchor_out, dim=1, keepdim=True)
        probabilities = exp_dot_tempered / (exp_sum + 1e-5) 

        # # Compute number of relevant positive samples for each anchor sample
        # cardinality_pos = torch.sum(mask_combined_pos, dim=1)

        # ## to avoid nan value of the loss if there is only one sample of a category  on the batch
        # for i in range(cardinality_pos.size(0)):
        #     if cardinality_pos[i]==0:
        #         cardinality_pos[i] = 1

        # # Compute log probability of positive pairs
        # log_prob = -torch.log(exp_dot_tempered / (torch.sum(exp_dot_tempered * mask_anchor_out, dim=1, keepdim=True)))
        # supervised_contrastive_loss_per_sample = torch.sum(log_prob * mask_combined_pos, dim=1) / cardinality_pos
        # supervised_contrastive_loss = torch.mean(supervised_contrastive_loss_per_sample)

        exp_sum_neg = torch.sum(exp_dot_tempered * mask_combined_neg)
        prob = exp_dot_tempered / (exp_dot_tempered + exp_sum_neg + 1e-5)

        log_prob = -torch.log(prob) * mask_combined_pos
        cardinality = torch.sum(mask_combined_pos + mask_combined_neg, dim=1, keepdim=True)
       
        for i in range(cardinality.size(0)):
            if cardinality[i]==0:
                cardinality[i] = 1

        total_loss = torch.mean(torch.sum(log_prob, dim=1) / cardinality)
        return total_loss

