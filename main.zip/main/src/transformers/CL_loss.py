import torch
import torch.nn as nn
from math import log    

class SupConLoss(nn.Module):
    def __init__(self, temperature=0.07, margin=0.2):
        """
        Implementation of the loss described in the paper Supervised Contrastive Learning :
        https://arxiv.org/abs/2004.11362
        :param temperature: int
        """
        super(SupConLoss, self).__init__()
        self.temperature = temperature
        self.cos = nn.CosineSimilarity(dim=-1)
        self.margin = margin

    def forward(self, projections, targets):
        """
        :param projections: torch.Tensor, shape [batch_size, projection_dim]
        :param targets: torch.Tensor, shape [batch_size]
        :return: torch.Tensor, scalar
        """
        device = torch.device("cuda") if projections.is_cuda else torch.device("cpu")

        # Compute similarity matrix
        ## dot_product_tempered = torch.mm(projections, projections.T) / self.temperature
        dot_product_tempered = self.cos(projections.unsqueeze(1), projections.unsqueeze(0)) / self.temperature

        # Compute softmax probabilities over all pairs (positive and negative)
        ## Minus max for numerical stability with exponential. Same done in cross entropy. Epsilon added to avoid log(0)
        exp_dot_tempered = (
            torch.exp(dot_product_tempered - torch.max(dot_product_tempered, dim=1, keepdim=True)[0]) + 1e-5
        )

        # Identify positive pairs for each anchor sample
        mask_similar_class = (targets.unsqueeze(1).repeat(1, targets.shape[0]) == targets).to(device)
        mask_anchor_out = (1 - torch.eye(exp_dot_tempered.shape[0])).to(device)
        mask_combined_pos = mask_similar_class * mask_anchor_out

        mask_diff_class = (targets.unsqueeze(1).repeat(1, targets.shape[0]) != targets).to(device)
        mask_combined_neg = mask_diff_class * mask_anchor_out

        # exp_sum = torch.sum(exp_dot_tempered * mask_anchor_out, dim=1, keepdim=True)
        # probabilities = exp_dot_tempered / (exp_sum + 1e-5) 

        # Compute number of relevant positive samples for each anchor sample
        cardinality_pos = torch.sum(mask_combined_pos, dim=1)

        ## to avoid nan value of the loss if there is only one sample of a category  on the batch
        for i in range(cardinality_pos.size(0)):
            if cardinality_pos[i]==0:
                cardinality_pos[i] = 1

        # # Compute log probability of positive pairs
        # log_prob = -torch.log(exp_dot_tempered / (torch.sum(exp_dot_tempered * mask_anchor_out, dim=1, keepdim=True)))
        # supervised_contrastive_loss_per_sample = torch.sum(log_prob * mask_combined_pos, dim=1) / cardinality_pos
        # supervised_contrastive_loss = torch.mean(supervised_contrastive_loss_per_sample)

        exp_sum_neg = torch.sum(exp_dot_tempered * mask_combined_neg)
        prob = exp_dot_tempered / (exp_dot_tempered + exp_sum_neg + 1e-5)

        log_prob = -torch.log(prob) * mask_combined_pos
       
        for i in range(cardinality_pos.size(0)):
            if cardinality_pos[i]==0:
                cardinality_pos[i] = 1

        total_loss = torch.mean(torch.sum(log_prob, dim=1) / cardinality_pos)
        return total_loss
