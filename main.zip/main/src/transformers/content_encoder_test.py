# Import library
import os
import random
import sys
sys.path.append("/home/thao/home/contrastive_aa/src/")

import json

import numpy as np

import datasets
from datasets import load_dataset

import transformers
from transformers import (
    AutoTokenizer,
    Seq2SeqTrainingArguments,
    Seq2SeqTrainer,
    Trainer,
    DataCollatorForSeq2Seq,
    TrainingArguments,
    EncoderDecoderModel,
    BertGenerationConfig,
    BertGenerationDecoder,
    BertGenerationEncoder,
    BertTokenizer, 
    BertTokenizerFast,
    BertForSequenceClassification, 
    BertModel,
    DataCollatorWithPadding)

import torch
from torch.utils.data import Dataset, DataLoader
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import evaluate
from torch.optim import AdamW

from dataloader import *


# raw_train_dataset, raw_test_dataset = get_dataset()

raw_train_dataset, raw_test_dataset = get_samples(len_test_sample=1, len_train_sample=1)

# Load pretrained model
# checkpoint = "/home/thao/home/contrastive_aa/AA_sum"
checkpoint = "bert-base-uncased"
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
rouge = evaluate.load("rouge")

encoder = BertGenerationEncoder.from_pretrained(checkpoint)
decoder = BertGenerationDecoder.from_pretrained(checkpoint, add_cross_attention=True, is_decoder=True)
bert2bert = EncoderDecoderModel(encoder=encoder, decoder=decoder)

# encoder.to(device)
# decoder.to(device)
# bert2bert.to(device)

# Set tokenizer
tokenizer = AutoTokenizer.from_pretrained(checkpoint)
loss_fn = nn.MSELoss()

def process_input(batch):
  inputs = tokenizer(batch["sentence1"], truncation=True, padding="max_length")
  outputs = tokenizer(batch["sentence1"], truncation=True, padding="max_length")

  batch["input_ids"] = inputs.input_ids
  batch["attention_mask"] = inputs.attention_mask
  
  batch["decoder_input_ids"] = outputs.input_ids
  batch["decoder_attention_mask"] = outputs.attention_mask

  batch["labels"] = outputs.input_ids.copy()
  return batch

def prepare_data(dataset,process_input=process_input, device=device):
    processed_data = dataset.map(
        process_input,
        batched=True,
        batch_size=16,
        remove_columns=["sentence1", "label"]
    )

    processed_data.set_format(
        type="torch",
        columns=["input_ids", "attention_mask", "decoder_input_ids", "decoder_attention_mask", "labels"],
    )

    return processed_data

train_data = prepare_data(raw_train_dataset)
eval_data = prepare_data(raw_test_dataset)

train_input_ids = train_data['input_ids']
eval_input_ids = eval_data['input_ids']

train_input_ids.to(device)
eval_input_ids.to(device)

# training_args = Seq2SeqTrainingArguments(
#     output_dir="/home/thao/contrastive_aa/AA_content/AA_content_res",
#     evaluation_strategy="epoch",
#     save_strategy="epoch",
#     warmup_steps=500,
#     weight_decay=0.01,
#     per_device_train_batch_size=8,
#     per_device_eval_batch_size=8,
#     num_train_epochs=3,
#     logging_steps=10,
#     predict_with_generate=True,
#     overwrite_output_dir=True,
#     fp16=True,
#     )

# trainer = Seq2SeqTrainer(
#     model=bert2bert,
#     tokenizer=tokenizer,
#     args=training_args,
#     train_dataset=train_data,
#     eval_dataset=val_data,
# )

# trainer.train()


# predict_results = trainer.predict(val_data)
# predictions = predict_results.predictions
# predictions = np.where(predictions != -100, predictions, tokenizer.pad_token_id)
# predictions = tokenizer.batch_decode(
#     predictions, skip_special_tokens=True, clean_up_tokenization_spaces=True
# )
# predictions = [pred.strip() for pred in predictions]

# output_file = '/home/thao/contrastive_aa/AA_content/predictions.json'
# with open(output_file, 'w') as f:
#     json.dump(predictions, f, indent=4)

