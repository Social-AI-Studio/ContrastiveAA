import sys
sys.path.append("/home/thao/home/contrastive_aa/src/")
import json
import datasets
from datasets import load_metric
import transformers
from transformers import (
    BertTokenizer, 
    AutoConfig,
    BertModel,)
import torch
from torch.utils.data import DataLoader
from dataloader import *

import numpy as np
import torch
import json

def get_embs(test_data, checkpoint='bert-base-uncased'):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    tokenizer = BertTokenizer.from_pretrained(checkpoint)
    model = BertModel.from_pretrained(checkpoint)
    model.to(device)
    model.eval()

    input_data = test_data['sentence1']
    input_label = test_data['label']
    embeddings_data = []
    
    for idx, text in enumerate(input_data):
        encoded_dict = tokenizer.encode_plus(
            text,
            truncation=True,
            padding="max_length",
            return_tensors='pt',
        )

        # Compute token embeddings
        with torch.no_grad():
            encoded_dict = encoded_dict.to(device)
            model_output = model(**encoded_dict)
            embeddings = model_output.last_hidden_state.squeeze().cpu().numpy()

        data_entry = {
            "embeddings": embeddings.tolist(),
            "label": input_label[idx]
        }

        embeddings_data.append(data_entry)
        
    return embeddings_data

def export_file(embeddings_data, json_file):
    with open(json_file, 'w') as f:
        json.dump(embeddings_data, f)

# Load Region Dataset
data_files = {
    "train": "/home/thao/home/contrastive_aa/data/AA_data/AA_cls_train.json", 
    "test": "/home/thao/home/contrastive_aa/data/AA_data/AA_cls_test.json"}
# train_data, test_data = get_dataset(data_files=data_files)
train_data, test_data = get_samples(data_files=data_files)

# # Embedding for region dataset
# embeddings_data = get_embs(test_data)
# json_file = '/home/thao/home/contrastive_aa/visusualization_emb/region_embeddings.json'
# # pickle_file = '/home/thao/home/contrastive_aa/visusualization_emb/region_embeddings.pkl'
# export_file(embeddings_data, json_file)

# Embedding for rgion dataset after doing contrastive
checkpoint = '/home/thao/home/contrastive_aa/AA_test_res'  
region_embeddings_data = get_embs(test_data, checkpoint)
json_file = '/home/thao/home/contrastive_aa/visusualization_emb/region_embeddings.json'
# pickle_file = '/home/thao/home/contrastive_aa/visusualization_emb/region_embeddings.pkl'
export_file(region_embeddings_data, json_file)

# Embedding for rgion dataset after doing contrastive
checkpoint = "/home/thao/home/contrastive_aa/AA_region_batchV6"
contrast_region_embeddings_data = get_embs(test_data, checkpoint)
json_file = '/home/thao/home/contrastive_aa/visusualization_emb/region_contrast_embeddings.json'
# pickle_file = '/home/thao/home/contrastive_aa/visusualization_emb/region_contrast_embeddings.pkl'
export_file(contrast_region_embeddings_data, json_file)

# Load CCAT50 Dataset
train_file = "/home/thao/home/contrastive_aa/data/CCAT50/processed/CCAT50_train.csv"
test_file = "/home/thao/home/contrastive_aa/data/CCAT50/processed/CCAT50_AA_test.csv"
train_data = get_csv_dataset(train_file)
test_data = get_csv_dataset(test_file)
train_data = train_data['train']
test_data = test_data['train']

# Embedding for region dataset
embeddings_data = get_embs(test_data)
json_file = '/home/thao/home/contrastive_aa/visusualization_emb/author_embeddings.json'
# pickle_file = '/home/thao/home/contrastive_aa/visusualization_emb/author_embeddings.pkl'
export_file(embeddings_data, json_file)

# Embedding for author dataset after doing contrastive
checkpoint = "/home/thao/home/contrastive_aa/AA_author"
author_embeddings_data = get_embs(test_data, checkpoint)
json_file = '/home/thao/home/contrastive_aa/visusualization_emb/author_embeddings.json'
# pickle_file = '/home/thao/home/contrastive_aa/visusualization_emb/author_embeddings.pkl'
export_file(author_embeddings_data, json_file)