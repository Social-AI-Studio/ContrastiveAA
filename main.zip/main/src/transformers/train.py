import argparse
import sys
sys.path.append("/home/thao/home/contrastive_aa/src/")

import torch
import torch.cuda
from torch.utils.data import DataLoader
from torch.nn.parallel import DataParallel

from dataloader import *
from content_encoder import *
from style_encoder import *
from dual_encoder import *
from MI_loss import *

def main(
    batch_size: int,
    num_epochs: int,
    log_step: int,
    num_iters: int,
    save_dir: str,
    ):
    torch.backends.cudnn.benchmark = True  

    # # Preare data
    # data_files = {
    #     "train": "/home/thao/home/contrastive_aa/data/AA_data/AA_cls_train.json", 
    #     "test": "/home/thao/home/contrastive_aa/data/AA_data/AA_cls_test.json"}
    # train_data, test_data = get_dataset(data_files=data_files)
    
    train_file = "/home/thao/home/contrastive_aa/data/CCAT50/processed/CCAT50_train.csv"
    test_file = "/home/thao/home/contrastive_aa/data/CCAT50/processed/CCAT50_AA_test.csv"
    train_data = get_csv_dataset(train_file)
    test_data = get_csv_dataset(test_file)
    
    train_data = train_data['train'].shuffle().select(range(100))
    test_data = test_data['train'].shuffle().select(range(100))
    
    # train_data, test_data = get_samples(data_files=data_files,len_train_sample=10000, len_test_sample=10000)

    # Load pretrained model
    # style_checkpoint = "/home/thao/home/contrastive_aa/AA_region_cls"
    style_checkpoint = "/home/thao/home/contrastive_aa/AA_author"
    # style_checkpoint = "/home/thao/home/contrastive_aa/AA_test_res"
    content_checkpoint = "bert-base-uncased"

    # Build model
    style_encoder = StyleEncoder(checkpoint=style_checkpoint, 
                                 train_data=train_data, 
                                 test_data=test_data)
    
    content_encoder = ContentEncoder(checkpoint=content_checkpoint,
                                     train_data=train_data,
                                     test_data=test_data)
    
    dual_encoder = DualEncoder(content_encoder=content_encoder,
                               style_encoder=style_encoder,
                               num_epochs=num_epochs,
                               batch_size=batch_size,
                               num_iters=num_iters,
                               log_step=log_step)

    # Train Step
    print("-------------------- Training --------------------")        
    dual_encoder.train_batch(train_data)
    
    print("-------------------- Saving Model --------------------")
    # Save model 
    # torch.save(style_encoder.model.state_dict(), "/home/thao/home/contrastive_aa/disentangle_res/style_encoder.pt")
    # torch.save(content_encoder.encoder.state_dict(), "/home/thao/home/contrastive_aa/disentangle_res/content_encoder.pt")
    
    # style_encoder.model.save_pretrained("/home/thao/home/contrastive_aa/disentangle_res/style_encoder")
    # style_encoder.tokenizer.save_pretrained("/home/thao/home/contrastive_aa/disentangle_res/style_encoder")

    # content_encoder.encoder.save_pretrained("/home/thao/home/contrastive_aa/disentangle_res/content_encoder")
    # content_encoder.tokenizer.save_pretrained("/home/thao/home/contrastive_aa/disentangle_res/style_encoder")
    # torch.save(dual_encoder.state_dict(), "/home/thao/home/contrastive_aa/disentangle_res/dual_encoder.pt")

    torch.save(style_encoder.model.state_dict(), "/home/thao/home/contrastive_aa/disentangle_res_authorV2/style_encoder.pt")
    torch.save(content_encoder.encoder.state_dict(), "/home/thao/home/contrastive_aa/disentangle_res_authorV2/content_encoder.pt")
    
    style_encoder.model.save_pretrained("/home/thao/home/contrastive_aa/disentangle_res_authorV2/style_encoder")
    style_encoder.tokenizer.save_pretrained("/home/thao/home/contrastive_aa/disentangle_res_authorV2/style_encoder")

    content_encoder.encoder.save_pretrained("/home/thao/home/contrastive_aa/disentangle_res_authorV2/content_encoder")
    content_encoder.tokenizer.save_pretrained("/home/thao/home/contrastive_aa/disentangle_res_authorV2/style_encoder")
    torch.save(dual_encoder.state_dict(), "/home/thao/home/contrastive_aa/disentangle_res_authorV2/dual_encoder.pt")

    # Test Step
    print("-------------------- Evaluation --------------------")
    save_dir = "/home/thao/home/contrastive_aa/disentangle_res_authorV2/result.json"
    style_checkpoint = "/home/thao/home/contrastive_aa/disentangle_res_authorV2/style_encoder"
    dual_encoder.test_step(style_checkpoint, train_data, test_data, save_dir)
    
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--batch_size", type=int, default=int(16))
    parser.add_argument("--num_epochs", type=int, default=int(1))
    parser.add_argument("--num_iters", type=int, default=100)
    parser.add_argument("--save_dir", type=str)
    # parser.add_argument("--log_step", type=int, default=10)
    # parser.add_argument("--do_train", action="store_true")
    # parser.add_argument("--do_evaluation", action="store_true")
    main(**vars(parser.parse_args()))
  