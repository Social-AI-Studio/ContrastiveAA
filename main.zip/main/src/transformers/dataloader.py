# Import library
import sys
sys.path.append("/home/thao/home/contrastive_aa/src/")
import numpy as np
import torch
from torch.utils.data import DataLoader, Dataset
import datasets
from datasets import load_dataset
import random

def get_dataset(data_files):
    loaded_dataset = load_dataset("json", data_files=data_files)

    train_dataset = loaded_dataset['train']
    test_dataset = loaded_dataset['test']
    return train_dataset, test_dataset

def get_samples(data_files, len_train_sample=100, len_test_sample=100):
    train_dataset, test_dataset = get_dataset(data_files)

    train_dataset_sample = train_dataset.shuffle().select(range(len_train_sample))
    test_dataset_sample = test_dataset.shuffle().select(range(len_test_sample))

    return train_dataset_sample, test_dataset_sample

def get_csv_dataset(data_file):
    dataset = load_dataset("csv", data_files=data_file)
    return dataset


def get_random(dataset):
    sampled_sentences = {}

    for data in dataset:
        label = data['label']
        sentence = data['sentence1']
        
        if label in sampled_sentences:
            sampled_sentences[label].append(sentence)
        else:
            sampled_sentences[label] = [sentence]

    final_sampled_sentences = {}
    for label, sentences in sampled_sentences.items():
        # Randomly sample 200 sentences for each label
        sampled = random.sample(sentences, k=min(200, len(sentences)))
        final_sampled_sentences[label] = sampled
    return final_sampled_sentences
