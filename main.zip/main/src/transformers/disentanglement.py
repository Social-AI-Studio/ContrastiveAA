# Import library
import os
import random
import sys
sys.path.append("/home/thao/home/contrastive_aa/src/")

import json

import datasets
from datasets import load_metric, load_dataset

import pandas as pd

import numpy as np

import transformers
from transformers import (
    BertTokenizer, 
    BertForSequenceClassification, 
    BertModel,
    DataCollatorWithPadding)

import torch
from torch.utils.data import Dataset, DataLoader

# Load pretrained model
checkpoint = "/home/thao/home/contrastive_aa/AA_region_cls"
tokenizer = BertTokenizer.from_pretrained(checkpoint, padding=True, truncation=True)
model = BertModel.from_pretrained(checkpoint)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
output_file = "/home/thao/home/contrastive_aa/test_out/result.json"
model.to(device)

# Load dataset
data_files = {
    "train": "/home/thao/home/contrastive_aa/data/AA_data/AA_cls_train.json", 
    "test": "/home/thao/home/contrastive_aa/data/AA_data/AA_cls_test.json"}

raw_train_dataset = load_dataset("json", data_files=data_files)['train'].shuffle().select(range(1000))
#raw_train_dataset = load_dataset("json", data_files=data_files)['train']
raw_test_dataset = load_dataset("json", data_files=data_files)['test'].shuffle().select(range(1000))
#raw_test_dataset = load_dataset("json", data_files=data_files)['test']

# Tokenize input sequence
tokens = tokenizer.encode(raw_train_dataset, add_special_tokens=True)
# Generate embeddings
input_ids = torch.tensor(tokens).unsqueeze(0)  # Add batch dimension
outputs = model(input_ids)
embeddings = outputs[0].squeeze(0) 


class LinearNorm(torch.nn.Module):
    def __init__(self, in_dim, out_dim, bias=True, w_init_gain='linear'):
        super(LinearNorm, self).__init__()
        self.linear_layer = torch.nn.Linear(in_dim, out_dim, bias=bias)

        torch.nn.init.xavier_uniform_(
            self.linear_layer.weight,
            gain=torch.nn.init.calculate_gain(w_init_gain))

    def forward(self, x):
        return self.linear_layer(x)


class ConvNorm(torch.nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size=1, stride=1,
                 padding=None, dilation=1, bias=True, w_init_gain='linear'):
        super(ConvNorm, self).__init__()
        if padding is None:
            assert(kernel_size % 2 == 1)
            padding = int(dilation * (kernel_size - 1) / 2)

        self.conv = torch.nn.Conv1d(in_channels, out_channels,
                                    kernel_size=kernel_size, stride=stride,
                                    padding=padding, dilation=dilation,
                                    bias=bias)

        torch.nn.init.xavier_uniform_(
            self.conv.weight, gain=torch.nn.init.calculate_gain(w_init_gain))

    def forward(self, signal):
        conv_signal = self.conv(signal)
        return conv_signal

class ContentEncoder(torch.nn.Module):
    def __init__(self, dim_emb, dim_out, freq = 16):
        super(ContentEncoder, self).__init__()
        self.dim_emb = dim_emb
        self.dim_out = dim_out
        self.freq = freq
        
        convolutions = []
        for i in range(3):
            conv_layer = torch.nn.Sequential(
                ConvNorm(512, 512,
                         kernel_size=5, stride=1,
                         padding=2,
                         dilation=1, w_init_gain='relu'),
                nn.BatchNorm1d(512))
            convolutions.append(conv_layer)
        self.convolutions = nn.ModuleList(convolutions)
        
        self.lstm = torch.nn.LSTM(512, 32, 2, batch_first=True, bidirectional=True)        

    def forward(self, x):
        for conv in self.convolutions:
            x = F.relu(conv(x)) 
                
        self.lstm.flatten_parameters()

        outputs, _ = self.lstm(x)  

        out_forward = outputs[:, :, :self.dim_out]
        out_backward = outputs[:, :, self.dim_out:]
        
        codes = []
        for i in range(0, outputs.size(1), self.freq):
            codes.append(torch.cat((out_forward[:,i+self.freq-1,:],out_backward[:,i,:]), dim=-1))
        return codes

