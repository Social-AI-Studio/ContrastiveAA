# Import library
import sys
sys.path.append("/home/thao/home/contrastive_aa/src/")
import torch
import transformers
from transformers import (
    BertTokenizer, 
    BertModel)

from dataloader import *

class StyleEncoder():
    def __init__(
            self, 
            checkpoint, 
            train_data, 
            test_data):
        
        self.checkpoint = checkpoint
        self.train_data = train_data
        self.test_data = test_data

        self.model = BertModel.from_pretrained(checkpoint)
        self.tokenizer = BertTokenizer.from_pretrained(checkpoint, padding=True, truncation=True)
        self.parameters = self.model.parameters()
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    
    def prepare_inputs(self, examples):
        tokenizer = self.tokenizer
        inputs = tokenizer.encode_plus(examples['sentence1'], padding="max_length", truncation=True)
        return inputs
    
    def prepare_data(self, data):
        processed_data = data.map(self.prepare_inputs)
        processed_data = processed_data.remove_columns(["sentence1", "label"])
        processed_data.set_format(type="torch",)
        return processed_data
    
    def get_style(self, encoded_dict):
        data_input_ids = encoded_dict['input_ids'].to(self.device)
        data_attention_mask = encoded_dict['attention_mask'].to(self.device)
        with torch.no_grad():
            model_output = self.model(input_ids=data_input_ids, attention_mask=data_attention_mask)
        # sentence_embedding = self.mean_pooling(model_output, encoded_dict['attention_mask'])
        last_hidden_states = model_output.last_hidden_state
        return last_hidden_states