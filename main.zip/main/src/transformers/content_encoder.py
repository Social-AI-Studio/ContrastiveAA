# Import library
import sys
sys.path.append("/home/thao/home/contrastive_aa/src/")
import torch
import transformers
from transformers import (
    AutoTokenizer,
    EncoderDecoderModel,
    BertGenerationDecoder,
    BertGenerationEncoder,)

import datasets
from datasets import Dataset

from dataloader import *

class ContentEncoder():
    def __init__(self, 
                 checkpoint, 
                 train_data,  
                 test_data,):       
        self.train_data = train_data
        self.test_data = test_data
        self.checkpoint = checkpoint

        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.encoder = BertGenerationEncoder.from_pretrained(self.checkpoint)
        self.tokenizer = AutoTokenizer.from_pretrained(self.checkpoint)
        self.lr = 1e-4
        
    def prepare_data(self, data):
        # data = Dataset.from_dict(data)
        processed_data = data.map(self.prepare_inputs,
            # batched=True, 
            # batch_size=16,
        )
        processed_data = processed_data.remove_columns(["sentence1", "label"])
        processed_data.set_format(
            type="torch",
            columns=["input_ids", "attention_mask", "decoder_input_ids", "decoder_attention_mask", "labels"],
        )
        return processed_data

    def prepare_inputs(self, examples):
        tokenizer = self.tokenizer
        inputs = tokenizer.encode_plus(examples["sentence1"], truncation=True, padding="max_length")
        outputs = tokenizer.encode_plus(examples["sentence1"], truncation=True, padding="max_length")

        examples["input_ids"] = inputs.input_ids
        examples["attention_mask"] = inputs.attention_mask
        examples["decoder_input_ids"] = outputs.input_ids
        examples["decoder_attention_mask"] = outputs.attention_mask
        examples["labels"] = outputs.input_ids.copy()
        return examples
    

    def get_content_embeddings(self, data):
        encoder = self.encoder.to(self.device)
        # data = self.prepare_data(data)
        data_input_ids = data['input_ids'].to(self.device)
        data_attention_mask = data['attention_mask'].to(self.device)

        with torch.no_grad():  
            outputs = encoder(input_ids=data_input_ids, attention_mask=data_attention_mask)

        last_hidden_states = outputs.last_hidden_state
        return last_hidden_states
    



