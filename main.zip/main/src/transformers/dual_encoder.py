# Import library
import sys
sys.path.append("/home/thao/home/contrastive_aa/src/")

import json
import torch
import torch.nn as nn
import time
import datetime

from dataloader import *
from content_encoder import *
from style_encoder import *
from MI_loss import *
from ranking_eva import *

class DualEncoder(nn.Module):
    def __init__(self, 
                 content_encoder, 
                 style_encoder,
                 num_epochs,
                 batch_size,
                 num_iters,
                 log_step,
                 lr=1e-4,
                 hidden_size=3):
        
        super(DualEncoder, self).__init__()
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.content_encoder = content_encoder
        self.style_encoder = style_encoder
        self.lr = lr
        self.num_iters = num_iters
        self.hidden_size = hidden_size
        self.num_epochs = num_epochs
        self.batch_size = batch_size  
        self.log_step = log_step
        self.content_opt = torch.optim.Adam(self.content_encoder.encoder.parameters(), self.lr)
        self.style_opt = torch.optim.Adam(self.style_encoder.model.parameters(), lr = self.lr)

    def test_step(self, style_checkpoint, train_data, test_data, output_file):
        ranking_eval = RegionComparison(checkpoint = style_checkpoint, 
                                        train_data=train_data, 
                                        test_data=test_data, 
                                        output_file=output_file)

        result_list = ranking_eval.compare_to_regions(train_data, test_data)
        with open(output_file, 'w') as f:
            for dictionary in result_list:
                json_string = json.dumps(dictionary)
                f.write(json_string + '\n')

        metrics_file = "/home/thao/home/contrastive_aa/disentangle_res_authorV2/metrics.json"
        accuracy_k = "/home/thao/home/contrastive_aa/AA_test_res/ranking_res/accuracy_k.json"
        
        metrics = ranking_eval.compute_metrics()
        with open(metrics_file, 'w') as f:
            json.dump(metrics, f, indent=4)
        
        result_topk = {}
        
        for i in range(1,4):
            metrics_topk = ranking_eval.compute_top_k(i)
            result_topk[f'Accuracy top-{i}'] = metrics_topk

        metrics_top10 = ranking_eval.compute_top_k(10)
        result_topk[f'Accuracy top-10'] = metrics_top10

        metrics_top20 = ranking_eval.compute_top_k(20)
        result_topk[f'Accuracy top-20'] = metrics_top20

        with open(accuracy_k, 'w') as f:
            json.dump(result_topk, f, indent=4)
        return metrics, result_topk

    def train_step(self, train_data):
        results = {}

        self.content_encoder.encoder.to(self.device)
        self.style_encoder.model.to(self.device)

        tokenized_content_data = self.content_encoder.prepare_data(train_data)
        tokenized_style_data = self.style_encoder.prepare_data(train_data)
                
        content_trainloader = DataLoader(tokenized_content_data, batch_size=self.batch_size, shuffle=True)
        style_trainloader = DataLoader(tokenized_style_data, batch_size=self.batch_size, shuffle=True)

        # Training Loop
        for epoch in range(self.num_epochs):
            self.content_encoder.encoder.train()
            self.style_encoder.model.train()
            total_loss = 0

            for i in range(self.num_iters):
                for batch1, batch2 in zip(content_trainloader, style_trainloader):
                    content_embedding = self.content_encoder.get_content_embeddings(batch1).to(self.device)
                    style_embedding = self.style_encoder.get_style(batch2).to(self.device)

                    mi_estimator = CLUB(content_embedding, style_embedding, hidden_size=self.hidden_size).to(self.device)
                    mi_estimator.eval()
                    sampler_loss = mi_estimator(content_embedding, style_embedding)

                    self.content_opt.zero_grad()
                    self.style_opt.zero_grad()

                    sampler_loss.backward() 

                    self.content_opt.step()
                    self.style_opt.step()

                for j in range(5):
                    mi_estimator.train()
                    for batch1, batch2 in zip(content_trainloader, style_trainloader):
                        content_embedding = self.content_encoder.get_content_embeddings(batch1)
                        style_embedding = self.style_encoder.get_style(batch2)

                        mi_optimizer = torch.optim.Adam(mi_estimator.parameters(), lr=self.lr)

                        mi_loss = mi_estimator.learning_loss(content_embedding, style_embedding)
                        mi_loss = torch.mean(mi_loss)

                        mi_optimizer.zero_grad()
                        mi_loss.backward()
                        mi_optimizer.step()

                mi_loss = mi_estimator.learning_loss(content_embedding, style_embedding)
                mi_loss = torch.mean(mi_loss)
                
                if i % 50 == 0:
                    print(f"Step {i+1} - Loss: {mi_loss:.4f}")

                loss = mi_loss.cpu().detach().numpy().tolist()
                results["step {}".format(i)] = loss
            
            mi_loss = mi_estimator.learning_loss(content_embedding, style_embedding)
            mi_loss = torch.mean(mi_loss)            
            total_loss += mi_loss

        average_loss = total_loss / len(content_trainloader)
        results["EPOCH {}:".format(i)] = average_loss
        print(f"Epoch {epoch+1}/{self.num_epochs} - Average Loss: {average_loss:.4f}")

        with open('/home/thao/home/contrastive_aa/disentangle_res/mi_loss.json', 'w') as json_file:
            json.dump(results, json_file, indent=4)
        return results

    def train_batch(self, train_data):
        results = {}

        self.content_encoder.encoder.to(self.device)
        self.style_encoder.model.to(self.device)

        tokenized_content_data = self.content_encoder.prepare_data(train_data)
        tokenized_style_data = self.style_encoder.prepare_data(train_data)
                
        content_trainloader = DataLoader(tokenized_content_data, batch_size=self.batch_size, shuffle=True)
        style_trainloader = DataLoader(tokenized_style_data, batch_size=self.batch_size, shuffle=True)

        epoch_losses = []
        # Training Loop
        for epoch in range(self.num_epochs):
            self.content_encoder.encoder.train()
            self.style_encoder.model.train()

            iter_losses = []
            
            for i in range(self.num_iters):
                iter_loss = 0
                for batch1, batch2 in zip(content_trainloader, style_trainloader):
                    content_embedding = self.content_encoder.get_content_embeddings(batch1)
                    style_embedding = self.style_encoder.get_style(batch2)

                    mi_estimator = CLUB(content_embedding, style_embedding, hidden_size=self.hidden_size).to(self.device)
                    mi_estimator.eval()
                    sampler_loss = mi_estimator(content_embedding, style_embedding)

                    self.content_opt.zero_grad()
                    self.style_opt.zero_grad()

                    sampler_loss.backward() 

                    self.content_opt.step()
                    self.style_opt.step()

                for j in range():
                    mi_estimator.train()
                    for batch1, batch2 in zip(content_trainloader, style_trainloader):
                        content_embedding = self.content_encoder.get_content_embeddings(batch1)
                        style_embedding = self.style_encoder.get_style(batch2)

                        mi_optimizer = torch.optim.Adam(mi_estimator.parameters(), lr=self.lr)

                        mi_loss = mi_estimator.learning_loss(content_embedding, style_embedding)
                        mi_loss = torch.mean(mi_loss)

                        mi_optimizer.zero_grad()
                        mi_loss.backward()
                        mi_optimizer.step()

                        iter_loss += mi_loss.item()
                
                iter_loss /= 10  
                iter_losses.append(iter_loss)
                if i % 10 == 0:
                    print(f"Step {i+1} - Loss: {iter_loss:.4f}")
                    # loss = iter_loss.cpu().detach().numpy().tolist()
                    results["step {}".format(i)] = iter_loss

            epoch_loss = sum(iter_losses) / len(iter_losses)
            epoch_losses.append(epoch_loss)
            results["EPOCH {}:".format(i)] = epoch_loss
            print(f"Epoch {epoch+1}/{self.num_epochs} - Average Loss: {epoch_loss:.4f}")

        with open('/home/thao/home/contrastive_aa/res_batch/mi_loss.json', 'w') as json_file:
            json.dump(results, json_file, indent=4)
        return results

 